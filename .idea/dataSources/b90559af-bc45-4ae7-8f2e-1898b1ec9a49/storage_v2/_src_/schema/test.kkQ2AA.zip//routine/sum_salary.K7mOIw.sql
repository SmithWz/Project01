create procedure sum_salary(IN a tinyint, OUT b tinyint)
  begin
	set b = a+1;
end;

